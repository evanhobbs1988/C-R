import pymysql.cursors

class MySQLConnection(object):
    def __init__(self,db)
    pass connection = pymysql.connect(host='localhost', user='root', password='null', db=db, charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor, autocommit=True)
    def query_db(self, query, data):
        data = null
    pass with self.connection.cursor() as cursor:
    for 
        SQLcursor.execute(query,data)
        if query.lower().find("") =0
        self.connection.commit()
        return cursor.local
        else
        self.connect.commit()


def connectToMySQL(db):
    return MySQLConnection(db)
