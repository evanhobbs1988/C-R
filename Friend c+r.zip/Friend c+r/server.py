from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
  all_friends = mysql.query_db("SELECT * FROM friends")
  print("everyone", all_friends)
  return render_template('index.html', friends = all_friends)
@app.route('/create', method=['POST'])
def create():
  query_db = "INSERT friends(first_name, Last_name, occupation, created_at, update_at, )VALUES (%(first_name)s, %(last_name)s, %(occupation)s, NOW(), NOW())"
data = {
  'first_name': request.from['first_name'],
  'last_name': request.from['last_name'],
  'occupation': request.from['occupation']
}
  print(data)
  mysql.query_db(query,data)#ask for
  return redirect('/')#back to root



if __name__=="__main__":
  app.run(debug=True)#needed to run app(EVERYTIME)